gdjs.GameCode = {};
gdjs.GameCode.localVariables = [];
gdjs.GameCode.idToCallbackMap = new Map();
gdjs.GameCode.GDFastSwimButtonObjects3_1final = [];

gdjs.GameCode.GDSharkObjects3_1final = [];

gdjs.GameCode.GDStaminaBarObjects3_1final = [];

gdjs.GameCode.forEachCount0_5 = 0;

gdjs.GameCode.forEachCount1_5 = 0;

gdjs.GameCode.forEachCount2_5 = 0;

gdjs.GameCode.forEachCount3_5 = 0;

gdjs.GameCode.forEachCount4_5 = 0;

gdjs.GameCode.forEachCount5_5 = 0;

gdjs.GameCode.forEachIndex3 = 0;

gdjs.GameCode.forEachIndex5 = 0;

gdjs.GameCode.forEachObjects3 = [];

gdjs.GameCode.forEachObjects5 = [];

gdjs.GameCode.forEachTemporary3 = null;

gdjs.GameCode.forEachTotalCount3 = 0;

gdjs.GameCode.forEachTotalCount5 = 0;

gdjs.GameCode.GDSharkObjects1= [];
gdjs.GameCode.GDSharkObjects2= [];
gdjs.GameCode.GDSharkObjects3= [];
gdjs.GameCode.GDSharkObjects4= [];
gdjs.GameCode.GDSharkObjects5= [];
gdjs.GameCode.GDCliff1Objects1= [];
gdjs.GameCode.GDCliff1Objects2= [];
gdjs.GameCode.GDCliff1Objects3= [];
gdjs.GameCode.GDCliff1Objects4= [];
gdjs.GameCode.GDCliff1Objects5= [];
gdjs.GameCode.GDCliff3Objects1= [];
gdjs.GameCode.GDCliff3Objects2= [];
gdjs.GameCode.GDCliff3Objects3= [];
gdjs.GameCode.GDCliff3Objects4= [];
gdjs.GameCode.GDCliff3Objects5= [];
gdjs.GameCode.GDBloodParticleEmitterObjects1= [];
gdjs.GameCode.GDBloodParticleEmitterObjects2= [];
gdjs.GameCode.GDBloodParticleEmitterObjects3= [];
gdjs.GameCode.GDBloodParticleEmitterObjects4= [];
gdjs.GameCode.GDBloodParticleEmitterObjects5= [];
gdjs.GameCode.GDSeaAndSkyObjects1= [];
gdjs.GameCode.GDSeaAndSkyObjects2= [];
gdjs.GameCode.GDSeaAndSkyObjects3= [];
gdjs.GameCode.GDSeaAndSkyObjects4= [];
gdjs.GameCode.GDSeaAndSkyObjects5= [];
gdjs.GameCode.GDMoveJoystickObjects1= [];
gdjs.GameCode.GDMoveJoystickObjects2= [];
gdjs.GameCode.GDMoveJoystickObjects3= [];
gdjs.GameCode.GDMoveJoystickObjects4= [];
gdjs.GameCode.GDMoveJoystickObjects5= [];
gdjs.GameCode.GDFishSpawnerObjects1= [];
gdjs.GameCode.GDFishSpawnerObjects2= [];
gdjs.GameCode.GDFishSpawnerObjects3= [];
gdjs.GameCode.GDFishSpawnerObjects4= [];
gdjs.GameCode.GDFishSpawnerObjects5= [];
gdjs.GameCode.GDRedSnapperObjects1= [];
gdjs.GameCode.GDRedSnapperObjects2= [];
gdjs.GameCode.GDRedSnapperObjects3= [];
gdjs.GameCode.GDRedSnapperObjects4= [];
gdjs.GameCode.GDRedSnapperObjects5= [];
gdjs.GameCode.GDClownfishObjects1= [];
gdjs.GameCode.GDClownfishObjects2= [];
gdjs.GameCode.GDClownfishObjects3= [];
gdjs.GameCode.GDClownfishObjects4= [];
gdjs.GameCode.GDClownfishObjects5= [];
gdjs.GameCode.GDParrotFishObjects1= [];
gdjs.GameCode.GDParrotFishObjects2= [];
gdjs.GameCode.GDParrotFishObjects3= [];
gdjs.GameCode.GDParrotFishObjects4= [];
gdjs.GameCode.GDParrotFishObjects5= [];
gdjs.GameCode.GDYellowTangObjects1= [];
gdjs.GameCode.GDYellowTangObjects2= [];
gdjs.GameCode.GDYellowTangObjects3= [];
gdjs.GameCode.GDYellowTangObjects4= [];
gdjs.GameCode.GDYellowTangObjects5= [];
gdjs.GameCode.GDHealthBarObjects1= [];
gdjs.GameCode.GDHealthBarObjects2= [];
gdjs.GameCode.GDHealthBarObjects3= [];
gdjs.GameCode.GDHealthBarObjects4= [];
gdjs.GameCode.GDHealthBarObjects5= [];
gdjs.GameCode.GDScoreTextObjects1= [];
gdjs.GameCode.GDScoreTextObjects2= [];
gdjs.GameCode.GDScoreTextObjects3= [];
gdjs.GameCode.GDScoreTextObjects4= [];
gdjs.GameCode.GDScoreTextObjects5= [];
gdjs.GameCode.GDAddScoreTextObjects1= [];
gdjs.GameCode.GDAddScoreTextObjects2= [];
gdjs.GameCode.GDAddScoreTextObjects3= [];
gdjs.GameCode.GDAddScoreTextObjects4= [];
gdjs.GameCode.GDAddScoreTextObjects5= [];
gdjs.GameCode.GDFastSwimButtonObjects1= [];
gdjs.GameCode.GDFastSwimButtonObjects2= [];
gdjs.GameCode.GDFastSwimButtonObjects3= [];
gdjs.GameCode.GDFastSwimButtonObjects4= [];
gdjs.GameCode.GDFastSwimButtonObjects5= [];
gdjs.GameCode.GDStaminaBarObjects1= [];
gdjs.GameCode.GDStaminaBarObjects2= [];
gdjs.GameCode.GDStaminaBarObjects3= [];
gdjs.GameCode.GDStaminaBarObjects4= [];
gdjs.GameCode.GDStaminaBarObjects5= [];
gdjs.GameCode.GDMultiplierTextObjects1= [];
gdjs.GameCode.GDMultiplierTextObjects2= [];
gdjs.GameCode.GDMultiplierTextObjects3= [];
gdjs.GameCode.GDMultiplierTextObjects4= [];
gdjs.GameCode.GDMultiplierTextObjects5= [];
gdjs.GameCode.GDLionfishObjects1= [];
gdjs.GameCode.GDLionfishObjects2= [];
gdjs.GameCode.GDLionfishObjects3= [];
gdjs.GameCode.GDLionfishObjects4= [];
gdjs.GameCode.GDLionfishObjects5= [];
gdjs.GameCode.GDAnglerfishObjects1= [];
gdjs.GameCode.GDAnglerfishObjects2= [];
gdjs.GameCode.GDAnglerfishObjects3= [];
gdjs.GameCode.GDAnglerfishObjects4= [];
gdjs.GameCode.GDAnglerfishObjects5= [];
gdjs.GameCode.GDBlackObjects1= [];
gdjs.GameCode.GDBlackObjects2= [];
gdjs.GameCode.GDBlackObjects3= [];
gdjs.GameCode.GDBlackObjects4= [];
gdjs.GameCode.GDBlackObjects5= [];
gdjs.GameCode.GDGameOverScoreTextObjects1= [];
gdjs.GameCode.GDGameOverScoreTextObjects2= [];
gdjs.GameCode.GDGameOverScoreTextObjects3= [];
gdjs.GameCode.GDGameOverScoreTextObjects4= [];
gdjs.GameCode.GDGameOverScoreTextObjects5= [];
gdjs.GameCode.GDMenuButtonObjects1= [];
gdjs.GameCode.GDMenuButtonObjects2= [];
gdjs.GameCode.GDMenuButtonObjects3= [];
gdjs.GameCode.GDMenuButtonObjects4= [];
gdjs.GameCode.GDMenuButtonObjects5= [];
gdjs.GameCode.GDSumbitScoreButtonObjects1= [];
gdjs.GameCode.GDSumbitScoreButtonObjects2= [];
gdjs.GameCode.GDSumbitScoreButtonObjects3= [];
gdjs.GameCode.GDSumbitScoreButtonObjects4= [];
gdjs.GameCode.GDSumbitScoreButtonObjects5= [];
gdjs.GameCode.GDHighscoreScoreTextObjects1= [];
gdjs.GameCode.GDHighscoreScoreTextObjects2= [];
gdjs.GameCode.GDHighscoreScoreTextObjects3= [];
gdjs.GameCode.GDHighscoreScoreTextObjects4= [];
gdjs.GameCode.GDHighscoreScoreTextObjects5= [];
gdjs.GameCode.GDSharkSpawnPointObjects1= [];
gdjs.GameCode.GDSharkSpawnPointObjects2= [];
gdjs.GameCode.GDSharkSpawnPointObjects3= [];
gdjs.GameCode.GDSharkSpawnPointObjects4= [];
gdjs.GameCode.GDSharkSpawnPointObjects5= [];
gdjs.GameCode.GDObstacleObjects1= [];
gdjs.GameCode.GDObstacleObjects2= [];
gdjs.GameCode.GDObstacleObjects3= [];
gdjs.GameCode.GDObstacleObjects4= [];
gdjs.GameCode.GDObstacleObjects5= [];
gdjs.GameCode.GDMineObjects1= [];
gdjs.GameCode.GDMineObjects2= [];
gdjs.GameCode.GDMineObjects3= [];
gdjs.GameCode.GDMineObjects4= [];
gdjs.GameCode.GDMineObjects5= [];
gdjs.GameCode.GDRedExplosionObjects1= [];
gdjs.GameCode.GDRedExplosionObjects2= [];
gdjs.GameCode.GDRedExplosionObjects3= [];
gdjs.GameCode.GDRedExplosionObjects4= [];
gdjs.GameCode.GDRedExplosionObjects5= [];
gdjs.GameCode.GDGrassObjects1= [];
gdjs.GameCode.GDGrassObjects2= [];
gdjs.GameCode.GDGrassObjects3= [];
gdjs.GameCode.GDGrassObjects4= [];
gdjs.GameCode.GDGrassObjects5= [];
gdjs.GameCode.GDGrass2Objects1= [];
gdjs.GameCode.GDGrass2Objects2= [];
gdjs.GameCode.GDGrass2Objects3= [];
gdjs.GameCode.GDGrass2Objects4= [];
gdjs.GameCode.GDGrass2Objects5= [];
gdjs.GameCode.GDLeftBoundaryObjects1= [];
gdjs.GameCode.GDLeftBoundaryObjects2= [];
gdjs.GameCode.GDLeftBoundaryObjects3= [];
gdjs.GameCode.GDLeftBoundaryObjects4= [];
gdjs.GameCode.GDLeftBoundaryObjects5= [];
gdjs.GameCode.GDTopBoundaryObjects1= [];
gdjs.GameCode.GDTopBoundaryObjects2= [];
gdjs.GameCode.GDTopBoundaryObjects3= [];
gdjs.GameCode.GDTopBoundaryObjects4= [];
gdjs.GameCode.GDTopBoundaryObjects5= [];
gdjs.GameCode.GDRightBoundaryObjects1= [];
gdjs.GameCode.GDRightBoundaryObjects2= [];
gdjs.GameCode.GDRightBoundaryObjects3= [];
gdjs.GameCode.GDRightBoundaryObjects4= [];
gdjs.GameCode.GDRightBoundaryObjects5= [];
gdjs.GameCode.GDBottomBoundaryObjects1= [];
gdjs.GameCode.GDBottomBoundaryObjects2= [];
gdjs.GameCode.GDBottomBoundaryObjects3= [];
gdjs.GameCode.GDBottomBoundaryObjects4= [];
gdjs.GameCode.GDBottomBoundaryObjects5= [];
gdjs.GameCode.GDBubblesParticleEmitterObjects1= [];
gdjs.GameCode.GDBubblesParticleEmitterObjects2= [];
gdjs.GameCode.GDBubblesParticleEmitterObjects3= [];
gdjs.GameCode.GDBubblesParticleEmitterObjects4= [];
gdjs.GameCode.GDBubblesParticleEmitterObjects5= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkSpawnPointObjects2Objects = Hashtable.newFrom({"SharkSpawnPoint": gdjs.GameCode.GDSharkSpawnPointObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects2Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubblesParticleEmitterObjects2Objects = Hashtable.newFrom({"BubblesParticleEmitter": gdjs.GameCode.GDBubblesParticleEmitterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects2Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects2});
gdjs.GameCode.mapOfEmptyGDRedSnapperObjectsEmptyGDClownfishObjectsEmptyGDParrotFishObjectsEmptyGDYellowTangObjectsEmptyGDLionfishObjectsEmptyGDAnglerfishObjects = Hashtable.newFrom({"RedSnapper": [], "Clownfish": [], "ParrotFish": [], "YellowTang": [], "Lionfish": [], "Anglerfish": []});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects5ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects5ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects5ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects5ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects5ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects5Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects5, "Clownfish": gdjs.GameCode.GDClownfishObjects5, "ParrotFish": gdjs.GameCode.GDParrotFishObjects5, "YellowTang": gdjs.GameCode.GDYellowTangObjects5, "Lionfish": gdjs.GameCode.GDLionfishObjects5, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects5});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


const repeatCount5 = gdjs.randomInRange(6, 16);
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {
gdjs.copyArray(gdjs.GameCode.GDFishSpawnerObjects3, gdjs.GameCode.GDFishSpawnerObjects5);

gdjs.GameCode.GDAnglerfishObjects5.length = 0;

gdjs.GameCode.GDClownfishObjects5.length = 0;

gdjs.GameCode.GDLionfishObjects5.length = 0;

gdjs.GameCode.GDParrotFishObjects5.length = 0;

gdjs.GameCode.GDRedSnapperObjects5.length = 0;

gdjs.GameCode.GDYellowTangObjects5.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDRedSnapperObjectsEmptyGDClownfishObjectsEmptyGDParrotFishObjectsEmptyGDYellowTangObjectsEmptyGDLionfishObjectsEmptyGDAnglerfishObjects) < 200);
}
if (isConditionTrue_0)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects5ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects5ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects5ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects5ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects5ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects5Objects, ((gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDFishSpawnerObjects5[0].getVariables()).getFromIndex(0).getAsString(), gdjs.randomInRange((( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getX()) - 100, (( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getX()) + 100), gdjs.randomInRange((( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getY()) - 100, (( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getY()) + 100), "");
}
}
}

}


};gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("Save", "Highscore");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("Save", "Highscore", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Level", 0, 0, 0);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.GameCode.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("FishSpawner"), gdjs.GameCode.GDFishSpawnerObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.GameCode.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.GameCode.GDObstacleObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.GameCode.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.GameCode.GDTopBoundaryObjects2);
{for(var i = 0, len = gdjs.GameCode.GDFishSpawnerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFishSpawnerObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.GameCode.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDObstacleObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.GameCode.GDLeftBoundaryObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLeftBoundaryObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameCode.GDTopBoundaryObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTopBoundaryObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameCode.GDRightBoundaryObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRightBoundaryObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameCode.GDBottomBoundaryObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBottomBoundaryObjects2[i].hide();
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SharkSpawnPoint"), gdjs.GameCode.GDSharkSpawnPointObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkSpawnPointObjects2Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkSpawnPointObjects2 */
gdjs.GameCode.GDSharkObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects2Objects, (( gdjs.GameCode.GDSharkSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDSharkSpawnPointObjects2[0].getCenterXInScene()), (( gdjs.GameCode.GDSharkSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDSharkSpawnPointObjects2[0].getCenterYInScene()), "");
}
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDSharkObjects2.length !== 0 ? gdjs.GameCode.GDSharkObjects2[0] : null), true, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SharkSpawnPoint"), gdjs.GameCode.GDSharkSpawnPointObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSharkSpawnPointObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkSpawnPointObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);
gdjs.GameCode.GDBubblesParticleEmitterObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBubblesParticleEmitterObjects2Objects, (( gdjs.GameCode.GDSharkObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects2[0].getX()), (( gdjs.GameCode.GDSharkObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects2[0].getY()) + 1000, "");
}
{for(var i = 0, len = gdjs.GameCode.GDBubblesParticleEmitterObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBubblesParticleEmitterObjects2[i].getBehavior("Object3D").setZ(-(1000));
}
}
{for(var i = 0, len = gdjs.GameCode.GDBubblesParticleEmitterObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBubblesParticleEmitterObjects2[i].getBehavior("Sticker").Stick(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects2Objects, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FastSwimButton"), gdjs.GameCode.GDFastSwimButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects2);
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDFastSwimButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFastSwimButtonObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.2, "", 0);
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("FishSpawner"), gdjs.GameCode.GDFishSpawnerObjects2);

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDFishSpawnerObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.GameCode.GDFishSpawnerObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDFishSpawnerObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDFishSpawnerObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects1[i].ActivateControl(false, null);
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMoveJoystickObjects1Objects = Hashtable.newFrom({"MoveJoystick": gdjs.GameCode.GDMoveJoystickObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.asyncCallback21435716 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "UI");
}
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile Controls");
}
{gdjs.evtTools.camera.showLayer(runtimeScene, "Game Over");
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21435716, gdjs.GameCode.asyncCallback21435716);
gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback21435716(runtimeScene, asyncObjectsList)), 21435716, asyncObjectsList);
}
}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21434060);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("Animation").setAnimationSpeedScale(0);
}
}

{ //Subevents
gdjs.GameCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 1.2);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Scale").setScale(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects3ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects3ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects3ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects3ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects3, "Clownfish": gdjs.GameCode.GDClownfishObjects3, "ParrotFish": gdjs.GameCode.GDParrotFishObjects3, "YellowTang": gdjs.GameCode.GDYellowTangObjects3, "Lionfish": gdjs.GameCode.GDLionfishObjects3, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects3ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects3ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects3ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects3ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects3, "Clownfish": gdjs.GameCode.GDClownfishObjects3, "ParrotFish": gdjs.GameCode.GDParrotFishObjects3, "YellowTang": gdjs.GameCode.GDYellowTangObjects3, "Lionfish": gdjs.GameCode.GDLionfishObjects3, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBloodParticleEmitterObjects5Objects = Hashtable.newFrom({"BloodParticleEmitter": gdjs.GameCode.GDBloodParticleEmitterObjects5});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAddScoreTextObjects5Objects = Hashtable.newFrom({"AddScoreText": gdjs.GameCode.GDAddScoreTextObjects5});
gdjs.GameCode.eventsList6 = function(runtimeScene) {

};gdjs.GameCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDAnglerfishObjects3, gdjs.GameCode.GDAnglerfishObjects4);

gdjs.copyArray(gdjs.GameCode.GDClownfishObjects3, gdjs.GameCode.GDClownfishObjects4);

gdjs.copyArray(gdjs.GameCode.GDLionfishObjects3, gdjs.GameCode.GDLionfishObjects4);

gdjs.copyArray(gdjs.GameCode.GDParrotFishObjects3, gdjs.GameCode.GDParrotFishObjects4);

gdjs.copyArray(gdjs.GameCode.GDRedSnapperObjects3, gdjs.GameCode.GDRedSnapperObjects4);

gdjs.copyArray(gdjs.GameCode.GDYellowTangObjects3, gdjs.GameCode.GDYellowTangObjects4);


gdjs.GameCode.forEachTotalCount5 = 0;
gdjs.GameCode.forEachObjects5.length = 0;
gdjs.GameCode.forEachCount0_5 = gdjs.GameCode.GDRedSnapperObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount0_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDRedSnapperObjects4);
gdjs.GameCode.forEachCount1_5 = gdjs.GameCode.GDClownfishObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount1_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDClownfishObjects4);
gdjs.GameCode.forEachCount2_5 = gdjs.GameCode.GDParrotFishObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount2_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDParrotFishObjects4);
gdjs.GameCode.forEachCount3_5 = gdjs.GameCode.GDYellowTangObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount3_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDYellowTangObjects4);
gdjs.GameCode.forEachCount4_5 = gdjs.GameCode.GDLionfishObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount4_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDLionfishObjects4);
gdjs.GameCode.forEachCount5_5 = gdjs.GameCode.GDAnglerfishObjects4.length;
gdjs.GameCode.forEachTotalCount5 += gdjs.GameCode.forEachCount5_5;
gdjs.GameCode.forEachObjects5.push.apply(gdjs.GameCode.forEachObjects5,gdjs.GameCode.GDAnglerfishObjects4);
for (gdjs.GameCode.forEachIndex5 = 0;gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachTotalCount5;++gdjs.GameCode.forEachIndex5) {
gdjs.copyArray(gdjs.GameCode.GDSharkObjects3, gdjs.GameCode.GDSharkObjects5);

gdjs.GameCode.GDAddScoreTextObjects5.length = 0;

gdjs.GameCode.GDBloodParticleEmitterObjects5.length = 0;

gdjs.GameCode.GDAnglerfishObjects5.length = 0;

gdjs.GameCode.GDClownfishObjects5.length = 0;

gdjs.GameCode.GDLionfishObjects5.length = 0;

gdjs.GameCode.GDParrotFishObjects5.length = 0;

gdjs.GameCode.GDRedSnapperObjects5.length = 0;

gdjs.GameCode.GDYellowTangObjects5.length = 0;


if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5) {
    gdjs.GameCode.GDRedSnapperObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
else if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5+gdjs.GameCode.forEachCount1_5) {
    gdjs.GameCode.GDClownfishObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
else if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5+gdjs.GameCode.forEachCount1_5+gdjs.GameCode.forEachCount2_5) {
    gdjs.GameCode.GDParrotFishObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
else if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5+gdjs.GameCode.forEachCount1_5+gdjs.GameCode.forEachCount2_5+gdjs.GameCode.forEachCount3_5) {
    gdjs.GameCode.GDYellowTangObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
else if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5+gdjs.GameCode.forEachCount1_5+gdjs.GameCode.forEachCount2_5+gdjs.GameCode.forEachCount3_5+gdjs.GameCode.forEachCount4_5) {
    gdjs.GameCode.GDLionfishObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
else if (gdjs.GameCode.forEachIndex5 < gdjs.GameCode.forEachCount0_5+gdjs.GameCode.forEachCount1_5+gdjs.GameCode.forEachCount2_5+gdjs.GameCode.forEachCount3_5+gdjs.GameCode.forEachCount4_5+gdjs.GameCode.forEachCount5_5) {
    gdjs.GameCode.GDAnglerfishObjects5.push(gdjs.GameCode.forEachObjects5[gdjs.GameCode.forEachIndex5]);
}
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(10 * Math.floor(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()));
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(0.2);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).add(0.001);
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects5[i].getBehavior("Health").Heal(10, null);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBloodParticleEmitterObjects5Objects, (( gdjs.GameCode.GDAnglerfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects5.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects5.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects5[0].getX()) :gdjs.GameCode.GDClownfishObjects5[0].getX()) :gdjs.GameCode.GDParrotFishObjects5[0].getX()) :gdjs.GameCode.GDYellowTangObjects5[0].getX()) :gdjs.GameCode.GDLionfishObjects5[0].getX()) :gdjs.GameCode.GDAnglerfishObjects5[0].getX()), (( gdjs.GameCode.GDAnglerfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects5.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects5.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects5[0].getY()) :gdjs.GameCode.GDClownfishObjects5[0].getY()) :gdjs.GameCode.GDParrotFishObjects5[0].getY()) :gdjs.GameCode.GDYellowTangObjects5[0].getY()) :gdjs.GameCode.GDLionfishObjects5[0].getY()) :gdjs.GameCode.GDAnglerfishObjects5[0].getY()), "");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAddScoreTextObjects5Objects, (( gdjs.GameCode.GDAnglerfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects5.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects5.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects5[0].getX()) :gdjs.GameCode.GDClownfishObjects5[0].getX()) :gdjs.GameCode.GDParrotFishObjects5[0].getX()) :gdjs.GameCode.GDYellowTangObjects5[0].getX()) :gdjs.GameCode.GDLionfishObjects5[0].getX()) :gdjs.GameCode.GDAnglerfishObjects5[0].getX()), (( gdjs.GameCode.GDAnglerfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects5.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects5.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects5.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects5[0].getY()) :gdjs.GameCode.GDClownfishObjects5[0].getY()) :gdjs.GameCode.GDParrotFishObjects5[0].getY()) :gdjs.GameCode.GDYellowTangObjects5[0].getY()) :gdjs.GameCode.GDLionfishObjects5[0].getY()) :gdjs.GameCode.GDAnglerfishObjects5[0].getY()), "");
}
{for(var i = 0, len = gdjs.GameCode.GDAddScoreTextObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDAddScoreTextObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(10 * Math.floor(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber())));
}
}
{for(var i = 0, len = gdjs.GameCode.GDAddScoreTextObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDAddScoreTextObjects5[i].getBehavior("Tween").addObjectPositionYTween2("Up", (gdjs.GameCode.GDAddScoreTextObjects5[i].getY()) - 100, "linear", 2, false);
}
}
{for(var i = 0, len = gdjs.GameCode.GDAddScoreTextObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDAddScoreTextObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Opacity", 0, "linear", 2, true);
}
}
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects5[i].deleteFromScene(runtimeScene);
}
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.GameCode.GDScoreTextObjects3);
{for(var i = 0, len = gdjs.GameCode.GDScoreTextObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDScoreTextObjects3[i].getBehavior("ScoreAnimation").SetValue(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), null);
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MultiplierTimer");
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects3, gdjs.GameCode.GDSharkObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects4[i].getBehavior("TopDownMovement").getMaxSpeed() < 500 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects4[k] = gdjs.GameCode.GDSharkObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects4[i].getBehavior("Animation").setAnimationName("Swim");
}
}
}

}


{

/* Reuse gdjs.GameCode.GDSharkObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").getMaxSpeed() == 500 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").setAnimationName("Swim Fast");
}
}
}

}


};gdjs.GameCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("RepeatTimer").Repeat2("HungerDamage", 0.5, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.GameCode.GDHealthBarObjects3);
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Health").Hit(1, false, false, null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Health").SetMaxHealthOp(Math.round(100 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()), null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBarObjects3[i].SetMaxValue((( gdjs.GameCode.GDSharkObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects3[0].getBehavior("Health").MaxHealth(null)), null);
}
}

{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects3);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects3);
gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);

gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects3ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects3ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects3ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects3ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").getAnimationName() == "Swim Bite") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.turnedTowardTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects3ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects3ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects3ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects3ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects, 180, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").setAnimationName("Swim Bite");
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Eat.wav", false, 100, 1);
}

{ //Subevents
gdjs.GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").getAnimationName() == "Swim Bite" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").setAnimationName("Swim");
}
}
}

}


{



}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getY() <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").setYVelocity(100);
}
}
}

}


{



}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);

gdjs.GameCode.GDFastSwimButtonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").getSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.GameCode.GDFastSwimButtonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FastSwimButton"), gdjs.GameCode.GDFastSwimButtonObjects4);
for (var i = 0, k = 0, l = gdjs.GameCode.GDFastSwimButtonObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDFastSwimButtonObjects4[i].getBehavior("MultitouchButton").IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDFastSwimButtonObjects4[k] = gdjs.GameCode.GDFastSwimButtonObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDFastSwimButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDFastSwimButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDFastSwimButtonObjects3_1final.indexOf(gdjs.GameCode.GDFastSwimButtonObjects4[j]) === -1 )
            gdjs.GameCode.GDFastSwimButtonObjects3_1final.push(gdjs.GameCode.GDFastSwimButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDFastSwimButtonObjects3_1final, gdjs.GameCode.GDFastSwimButtonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21447796);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(500);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").setAngularMaxSpeed(200);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "FastSwim.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").getMaxSpeed() == 500 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("StaminaBar"), gdjs.GameCode.GDStaminaBarObjects3);
{for(var i = 0, len = gdjs.GameCode.GDStaminaBarObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDStaminaBarObjects3[i].SetValue(gdjs.GameCode.GDStaminaBarObjects3[i].Value(null) - (12 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)), null);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);

gdjs.copyArray(runtimeScene.getObjects("StaminaBar"), gdjs.GameCode.GDStaminaBarObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").getMaxSpeed() < 500 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDStaminaBarObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDStaminaBarObjects3[i].Value(null) < 100 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDStaminaBarObjects3[k] = gdjs.GameCode.GDStaminaBarObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDStaminaBarObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDStaminaBarObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDStaminaBarObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDStaminaBarObjects3[i].SetValue(gdjs.GameCode.GDStaminaBarObjects3[i].Value(null) + (6 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)), null);
}
}
}

}


{

gdjs.GameCode.GDFastSwimButtonObjects3.length = 0;

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);

gdjs.GameCode.GDStaminaBarObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDFastSwimButtonObjects3_1final.length = 0;
gdjs.GameCode.GDSharkObjects3_1final.length = 0;
gdjs.GameCode.GDStaminaBarObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("FastSwimButton"), gdjs.GameCode.GDFastSwimButtonObjects4);
for (var i = 0, k = 0, l = gdjs.GameCode.GDFastSwimButtonObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDFastSwimButtonObjects4[i].getBehavior("MultitouchButton").IsReleased(null) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDFastSwimButtonObjects4[k] = gdjs.GameCode.GDFastSwimButtonObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDFastSwimButtonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDFastSwimButtonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDFastSwimButtonObjects3_1final.indexOf(gdjs.GameCode.GDFastSwimButtonObjects4[j]) === -1 )
            gdjs.GameCode.GDFastSwimButtonObjects3_1final.push(gdjs.GameCode.GDFastSwimButtonObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("StaminaBar"), gdjs.GameCode.GDStaminaBarObjects4);
for (var i = 0, k = 0, l = gdjs.GameCode.GDStaminaBarObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDStaminaBarObjects4[i].Value(null) <= 0 ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDStaminaBarObjects4[k] = gdjs.GameCode.GDStaminaBarObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDStaminaBarObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDStaminaBarObjects4.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDStaminaBarObjects3_1final.indexOf(gdjs.GameCode.GDStaminaBarObjects4[j]) === -1 )
            gdjs.GameCode.GDStaminaBarObjects3_1final.push(gdjs.GameCode.GDStaminaBarObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects4);

for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects4[i].getBehavior("TopDownMovement").getSpeed() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDSharkObjects4[k] = gdjs.GameCode.GDSharkObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDSharkObjects4.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDSharkObjects3_1final.indexOf(gdjs.GameCode.GDSharkObjects4[j]) === -1 )
            gdjs.GameCode.GDSharkObjects3_1final.push(gdjs.GameCode.GDSharkObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDFastSwimButtonObjects3_1final, gdjs.GameCode.GDFastSwimButtonObjects3);
gdjs.copyArray(gdjs.GameCode.GDSharkObjects3_1final, gdjs.GameCode.GDSharkObjects3);
gdjs.copyArray(gdjs.GameCode.GDStaminaBarObjects3_1final, gdjs.GameCode.GDStaminaBarObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects);
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(300);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").setAngularMaxSpeed(180);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDSharkObjects2, gdjs.GameCode.GDSharkObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDSharkObjects3[i].getBehavior("Animation").getAnimationName() == "Swim Bite") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects3[i].getBehavior("TopDownMovement").getSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects3[k] = gdjs.GameCode.GDSharkObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDMoveJoystickObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDMoveJoystickObjects2[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDMoveJoystickObjects2[k] = gdjs.GameCode.GDMoveJoystickObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDMoveJoystickObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDMoveJoystickObjects2 */
/* Reuse gdjs.GameCode.GDSharkObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("TopDownMovement").simulateStick((( gdjs.GameCode.GDMoveJoystickObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDMoveJoystickObjects2[0].StickAngle(null)), (( gdjs.GameCode.GDMoveJoystickObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDMoveJoystickObjects2[0].StickForce(null)));
}
}
}

}


};gdjs.GameCode.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.GameCode.GDBottomBoundaryObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.GameCode.GDLeftBoundaryObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.GameCode.GDRightBoundaryObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects1);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.GameCode.GDTopBoundaryObjects1);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.GameCode.GDLeftBoundaryObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDLeftBoundaryObjects1[0].getPointX("")) + (( gdjs.GameCode.GDSharkObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects1[0].getY()) / 2, (( gdjs.GameCode.GDTopBoundaryObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDTopBoundaryObjects1[0].getPointY("")), (( gdjs.GameCode.GDRightBoundaryObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDRightBoundaryObjects1[0].getPointX("")) - (( gdjs.GameCode.GDSharkObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects1[0].getY()) / 2, (( gdjs.GameCode.GDBottomBoundaryObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDBottomBoundaryObjects1[0].getPointY("")), "", 0);
}
}

}


};gdjs.GameCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.GameCode.GDObstacleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDSharkObjects2[i].getAngle()));
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSharkObjects2[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects2[k] = gdjs.GameCode.GDSharkObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects2);
/* Reuse gdjs.GameCode.GDSharkObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("TopDownMovement").setYVelocity(100);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("TopDownMovement").ignoreDefaultControls(true);
}
}
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects2[i].ActivateControl(false, null);
}
}

{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSharkObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDSharkObjects2[i].getBehavior("Health").IsDead(null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSharkObjects2[k] = gdjs.GameCode.GDSharkObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSharkObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.GameCode.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);
{for(var i = 0, len = gdjs.GameCode.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBarObjects2[i].SetValue((( gdjs.GameCode.GDSharkObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDSharkObjects2[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{


gdjs.GameCode.eventsList10(runtimeScene);
}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMineObjects1Objects = Hashtable.newFrom({"Mine": gdjs.GameCode.GDMineObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedExplosionObjects1Objects = Hashtable.newFrom({"RedExplosion": gdjs.GameCode.GDRedExplosionObjects1});
gdjs.GameCode.asyncCallback21461468 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Shark"), gdjs.GameCode.GDSharkObjects3);

{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Tween3D").TweenTint("Flash", "255;255;255", 0.2, "easeInQuad", null);
}
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21461468, gdjs.GameCode.asyncCallback21461468);
gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
for (const obj of gdjs.GameCode.GDSharkObjects2) asyncObjectsList.addObject("Shark", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameCode.asyncCallback21461468(runtimeScene, asyncObjectsList)), 21461468, asyncObjectsList);
}
}

}


};gdjs.GameCode.asyncCallback21462020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Shark"), gdjs.GameCode.GDSharkObjects2);

{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("TopDownMovement").ignoreDefaultControls(false);
}
}
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects2[i].ActivateControl(true, null);
}
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21462020, gdjs.GameCode.asyncCallback21462020);
gdjs.GameCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
for (const obj of gdjs.GameCode.GDMoveJoystickObjects1) asyncObjectsList.addObject("MoveJoystick", obj);
for (const obj of gdjs.GameCode.GDSharkObjects1) asyncObjectsList.addObject("Shark", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback21462020(runtimeScene, asyncObjectsList)), 21462020, asyncObjectsList);
}
}

}


};gdjs.GameCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDSharkObjects1, gdjs.GameCode.GDSharkObjects2);

{for(var i = 0, len = gdjs.GameCode.GDSharkObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects2[i].getBehavior("Tween3D").TweenTint("Flash", "208;65;58", 0.2, "easeOutQuad", null);
}
}

{ //Subevents
gdjs.GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects1);
/* Reuse gdjs.GameCode.GDSharkObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects1[i].getBehavior("TopDownMovement").ignoreDefaultControls(true);
}
}
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects1[i].ActivateControl(false, null);
}
}

{ //Subevents
gdjs.GameCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Mine"), gdjs.GameCode.GDMineObjects2);
{for(var i = 0, len = gdjs.GameCode.GDMineObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMineObjects2[i].getBehavior("Object3D").setRotationY(gdjs.GameCode.GDMineObjects2[i].getBehavior("Object3D").getRotationY() + (0.5));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mine"), gdjs.GameCode.GDMineObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMineObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDMineObjects1 */
/* Reuse gdjs.GameCode.GDSharkObjects1 */
gdjs.GameCode.GDRedExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedExplosionObjects1Objects, (( gdjs.GameCode.GDMineObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDMineObjects1[0].getCenterXInScene()), (( gdjs.GameCode.GDMineObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDMineObjects1[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.GameCode.GDMineObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMineObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 2, 0.5, 2, null);
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects1[i].getBehavior("ShakeModel3D").Shake(1, 0.5, 0.5, null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects1[i].getBehavior("Health").Hit(40, false, false, null);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "20c1edc1dad3064721fc9a0621345e2b79198fae67e5a31cc9c3145b6654ba90_Explosion 6.aac", false, 50, 1);
}

{ //Subevents
gdjs.GameCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21467508);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "MultiplierActive.aac", false, 20, 1);
}
}

}


};gdjs.GameCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "MultiplierTimer") >= 5;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MultiplierText"), gdjs.GameCode.GDMultiplierTextObjects2);
{for(var i = 0, len = gdjs.GameCode.GDMultiplierTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMultiplierTextObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.floor(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber())) + "X");
}
}
{for(var i = 0, len = gdjs.GameCode.GDMultiplierTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMultiplierTextObjects2[i].setCenterXInScene(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.floor(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()) < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MultiplierText"), gdjs.GameCode.GDMultiplierTextObjects2);
{for(var i = 0, len = gdjs.GameCode.GDMultiplierTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMultiplierTextObjects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.floor(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()) >= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MultiplierText"), gdjs.GameCode.GDMultiplierTextObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMultiplierTextObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMultiplierTextObjects1[i].hide(false);
}
}

{ //Subevents
gdjs.GameCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfEmptyGDRedSnapperObjectsEmptyGDClownfishObjectsEmptyGDParrotFishObjectsEmptyGDYellowTangObjectsEmptyGDLionfishObjectsEmptyGDAnglerfishObjects = Hashtable.newFrom({"RedSnapper": [], "Clownfish": [], "ParrotFish": [], "YellowTang": [], "Lionfish": [], "Anglerfish": []});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects5ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects5ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects5ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects5ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects5ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects5Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects5, "Clownfish": gdjs.GameCode.GDClownfishObjects5, "ParrotFish": gdjs.GameCode.GDParrotFishObjects5, "YellowTang": gdjs.GameCode.GDYellowTangObjects5, "Lionfish": gdjs.GameCode.GDLionfishObjects5, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects5});
gdjs.GameCode.eventsList18 = function(runtimeScene) {

};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{


const repeatCount5 = gdjs.randomInRange(6, 16);
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {
gdjs.copyArray(gdjs.GameCode.GDFishSpawnerObjects3, gdjs.GameCode.GDFishSpawnerObjects5);

gdjs.GameCode.GDAnglerfishObjects5.length = 0;

gdjs.GameCode.GDClownfishObjects5.length = 0;

gdjs.GameCode.GDLionfishObjects5.length = 0;

gdjs.GameCode.GDParrotFishObjects5.length = 0;

gdjs.GameCode.GDRedSnapperObjects5.length = 0;

gdjs.GameCode.GDYellowTangObjects5.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDRedSnapperObjectsEmptyGDClownfishObjectsEmptyGDParrotFishObjectsEmptyGDYellowTangObjectsEmptyGDLionfishObjectsEmptyGDAnglerfishObjects) < 200);
}
if (isConditionTrue_0)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects5ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects5ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects5ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects5ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects5ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects5Objects, ((gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDFishSpawnerObjects5[0].getVariables()).getFromIndex(0).getAsString(), gdjs.randomInRange((( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getX()) - 100, (( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getX()) + 100), gdjs.randomInRange((( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getY()) - 100, (( gdjs.GameCode.GDFishSpawnerObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDFishSpawnerObjects5[0].getY()) + 100), "");
}
}
}

}


};gdjs.GameCode.eventsList20 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDFishSpawnerObjects2 */

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDFishSpawnerObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.GameCode.GDFishSpawnerObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDFishSpawnerObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDFishSpawnerObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameCode.eventsList19(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FishSpawner"), gdjs.GameCode.GDFishSpawnerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpawnFish", 60, null);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDFishSpawnerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDFishSpawnerObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDFishSpawnerObjects2[k] = gdjs.GameCode.GDFishSpawnerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDFishSpawnerObjects2.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects3);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects3);
gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDRedSnapperObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDRedSnapperObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDRedSnapperObjects3[k] = gdjs.GameCode.GDRedSnapperObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDRedSnapperObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDClownfishObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDClownfishObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDClownfishObjects3[k] = gdjs.GameCode.GDClownfishObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDClownfishObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDParrotFishObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDParrotFishObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDParrotFishObjects3[k] = gdjs.GameCode.GDParrotFishObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDParrotFishObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDYellowTangObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDYellowTangObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDYellowTangObjects3[k] = gdjs.GameCode.GDYellowTangObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDYellowTangObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDLionfishObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDLionfishObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDLionfishObjects3[k] = gdjs.GameCode.GDLionfishObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDLionfishObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAnglerfishObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDAnglerfishObjects3[i].getBehavior("InOnScreen").IsOnScreen(200, null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAnglerfishObjects3[k] = gdjs.GameCode.GDAnglerfishObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDAnglerfishObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects3 */
/* Reuse gdjs.GameCode.GDClownfishObjects3 */
/* Reuse gdjs.GameCode.GDLionfishObjects3 */
/* Reuse gdjs.GameCode.GDParrotFishObjects3 */
/* Reuse gdjs.GameCode.GDRedSnapperObjects3 */
/* Reuse gdjs.GameCode.GDYellowTangObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects3[i].activateBehavior("BoidsMovement", true);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects3[i].activateBehavior("BoidsMovement", true);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects3[i].activateBehavior("BoidsMovement", true);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects3[i].activateBehavior("BoidsMovement", true);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects3[i].activateBehavior("BoidsMovement", true);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects3[i].activateBehavior("BoidsMovement", true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects2);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects2);
gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDRedSnapperObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDRedSnapperObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDRedSnapperObjects2[k] = gdjs.GameCode.GDRedSnapperObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDRedSnapperObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDClownfishObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDClownfishObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDClownfishObjects2[k] = gdjs.GameCode.GDClownfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDClownfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDParrotFishObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDParrotFishObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDParrotFishObjects2[k] = gdjs.GameCode.GDParrotFishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDParrotFishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDYellowTangObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDYellowTangObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDYellowTangObjects2[k] = gdjs.GameCode.GDYellowTangObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDYellowTangObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDLionfishObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDLionfishObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDLionfishObjects2[k] = gdjs.GameCode.GDLionfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDLionfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAnglerfishObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("InOnScreen").IsOnScreen(200, null)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAnglerfishObjects2[k] = gdjs.GameCode.GDAnglerfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDAnglerfishObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects2 */
/* Reuse gdjs.GameCode.GDClownfishObjects2 */
/* Reuse gdjs.GameCode.GDLionfishObjects2 */
/* Reuse gdjs.GameCode.GDParrotFishObjects2 */
/* Reuse gdjs.GameCode.GDRedSnapperObjects2 */
/* Reuse gdjs.GameCode.GDYellowTangObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects2[i].activateBehavior("BoidsMovement", false);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects2[i].activateBehavior("BoidsMovement", false);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects2[i].activateBehavior("BoidsMovement", false);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects2[i].activateBehavior("BoidsMovement", false);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects2[i].activateBehavior("BoidsMovement", false);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects2[i].activateBehavior("BoidsMovement", false);
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects = Hashtable.newFrom({"Anglerfish": gdjs.GameCode.GDAnglerfishObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects = Hashtable.newFrom({"Lionfish": gdjs.GameCode.GDLionfishObjects3, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBloodParticleEmitterObjects3Objects = Hashtable.newFrom({"BloodParticleEmitter": gdjs.GameCode.GDBloodParticleEmitterObjects3});
gdjs.GameCode.asyncCallback21475956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Shark"), gdjs.GameCode.GDSharkObjects4);

{for(var i = 0, len = gdjs.GameCode.GDSharkObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects4[i].getBehavior("Tween3D").TweenTint("Flash", "255;255;255", 0.2, "easeInQuad", null);
}
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21475956, gdjs.GameCode.asyncCallback21475956);
gdjs.GameCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
for (const obj of gdjs.GameCode.GDSharkObjects3) asyncObjectsList.addObject("Shark", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameCode.asyncCallback21475956(runtimeScene, asyncObjectsList)), 21475956, asyncObjectsList);
}
}

}


};gdjs.GameCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects, 400, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects3 */
/* Reuse gdjs.GameCode.GDSharkObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects3[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects, 30, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects3);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDLionfishObjects3ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21474380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects3 */
/* Reuse gdjs.GameCode.GDLionfishObjects3 */
/* Reuse gdjs.GameCode.GDSharkObjects3 */
gdjs.GameCode.GDBloodParticleEmitterObjects3.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDLionfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects3[i].getBehavior("Animation").setAnimationName("Attack");
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects3[i].getBehavior("Animation").setAnimationName("Attack");
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Damage.wav", false, 100, 1);
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("ShakeModel3D").Shake(1, 0.5, 0.5, null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Health").Hit(20, false, false, null);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBloodParticleEmitterObjects3Objects, (( gdjs.GameCode.GDAnglerfishObjects3.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLionfishObjects3[0].getX()) :gdjs.GameCode.GDAnglerfishObjects3[0].getX()), (( gdjs.GameCode.GDAnglerfishObjects3.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDLionfishObjects3[0].getY()) :gdjs.GameCode.GDAnglerfishObjects3[0].getY()), "");
}
{for(var i = 0, len = gdjs.GameCode.GDSharkObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSharkObjects3[i].getBehavior("Tween3D").TweenTint("Flash", "208;65;58", 0.2, "easeOutQuad", null);
}
}

{ //Subevents
gdjs.GameCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDLionfishObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDLionfishObjects2[i].getBehavior("Animation").getAnimationName() == "Attack" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDLionfishObjects2[k] = gdjs.GameCode.GDLionfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDLionfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAnglerfishObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("Animation").getAnimationName() == "Attack" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAnglerfishObjects2[k] = gdjs.GameCode.GDAnglerfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDAnglerfishObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDLionfishObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDLionfishObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDLionfishObjects2[k] = gdjs.GameCode.GDLionfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDLionfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAnglerfishObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAnglerfishObjects2[k] = gdjs.GameCode.GDAnglerfishObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDAnglerfishObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects2 */
/* Reuse gdjs.GameCode.GDLionfishObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDLionfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects2ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects2ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects2ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects2ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects2ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects2Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects2, "Clownfish": gdjs.GameCode.GDClownfishObjects2, "ParrotFish": gdjs.GameCode.GDParrotFishObjects2, "YellowTang": gdjs.GameCode.GDYellowTangObjects2, "Lionfish": gdjs.GameCode.GDLionfishObjects2, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects = Hashtable.newFrom({"FishSpawner": gdjs.GameCode.GDFishSpawnerObjects2});
gdjs.GameCode.eventsList25 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDAnglerfishObjects2 */
/* Reuse gdjs.GameCode.GDClownfishObjects2 */
gdjs.copyArray(runtimeScene.getObjects("FishSpawner"), gdjs.GameCode.GDFishSpawnerObjects2);
/* Reuse gdjs.GameCode.GDLionfishObjects2 */
/* Reuse gdjs.GameCode.GDParrotFishObjects2 */
/* Reuse gdjs.GameCode.GDRedSnapperObjects2 */
/* Reuse gdjs.GameCode.GDYellowTangObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, (( gdjs.GameCode.GDAnglerfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects2.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects2.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects2[0].getX()) :gdjs.GameCode.GDClownfishObjects2[0].getX()) :gdjs.GameCode.GDParrotFishObjects2[0].getX()) :gdjs.GameCode.GDYellowTangObjects2[0].getX()) :gdjs.GameCode.GDLionfishObjects2[0].getX()) :gdjs.GameCode.GDAnglerfishObjects2[0].getX()), (( gdjs.GameCode.GDAnglerfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDLionfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDYellowTangObjects2.length === 0 ) ? (( gdjs.GameCode.GDParrotFishObjects2.length === 0 ) ? (( gdjs.GameCode.GDClownfishObjects2.length === 0 ) ? (( gdjs.GameCode.GDRedSnapperObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDRedSnapperObjects2[0].getY()) :gdjs.GameCode.GDClownfishObjects2[0].getY()) :gdjs.GameCode.GDParrotFishObjects2[0].getY()) :gdjs.GameCode.GDYellowTangObjects2[0].getY()) :gdjs.GameCode.GDLionfishObjects2[0].getY()) :gdjs.GameCode.GDAnglerfishObjects2[0].getY()), false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects2 */
/* Reuse gdjs.GameCode.GDClownfishObjects2 */
/* Reuse gdjs.GameCode.GDFishSpawnerObjects2 */
/* Reuse gdjs.GameCode.GDLionfishObjects2 */
/* Reuse gdjs.GameCode.GDParrotFishObjects2 */
/* Reuse gdjs.GameCode.GDRedSnapperObjects2 */
/* Reuse gdjs.GameCode.GDYellowTangObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFishSpawnerObjects2Objects, 100, null);
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects = Hashtable.newFrom({"SeaAndSky": gdjs.GameCode.GDSeaAndSkyObjects2, "Obstacle": gdjs.GameCode.GDObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects1ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects1ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects1ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects1ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects1ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects1Objects = Hashtable.newFrom({"RedSnapper": gdjs.GameCode.GDRedSnapperObjects1, "Clownfish": gdjs.GameCode.GDClownfishObjects1, "ParrotFish": gdjs.GameCode.GDParrotFishObjects1, "YellowTang": gdjs.GameCode.GDYellowTangObjects1, "Lionfish": gdjs.GameCode.GDLionfishObjects1, "Anglerfish": gdjs.GameCode.GDAnglerfishObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects = Hashtable.newFrom({"Shark": gdjs.GameCode.GDSharkObjects1});
gdjs.GameCode.eventsList26 = function(runtimeScene) {

{


gdjs.GameCode.eventsList21(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "Fish", 1, null);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList24(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.GameCode.GDObstacleObjects2);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects2);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects2);
gdjs.copyArray(runtimeScene.getObjects("SeaAndSky"), gdjs.GameCode.GDSeaAndSkyObjects2);
gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects2ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects2ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects2ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects2ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects2ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.GameCode.GDObstacleObjects2);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects2);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects2);
gdjs.copyArray(runtimeScene.getObjects("SeaAndSky"), gdjs.GameCode.GDSeaAndSkyObjects2);
gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects2);
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDRedSnapperObjects2[i].getAngle()));
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDClownfishObjects2[i].getAngle()));
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDParrotFishObjects2[i].getAngle()));
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDYellowTangObjects2[i].getAngle()));
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDLionfishObjects2[i].getAngle()));
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects2[i].getBehavior("Object3D").setRotationX((gdjs.GameCode.GDAnglerfishObjects2[i].getAngle()));
}
}
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSeaAndSkyObjects2ObjectsGDgdjs_9546GameCode_9546GDObstacleObjects2Objects, false);
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Anglerfish"), gdjs.GameCode.GDAnglerfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Clownfish"), gdjs.GameCode.GDClownfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lionfish"), gdjs.GameCode.GDLionfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("ParrotFish"), gdjs.GameCode.GDParrotFishObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedSnapper"), gdjs.GameCode.GDRedSnapperObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shark"), gdjs.GameCode.GDSharkObjects1);
gdjs.copyArray(runtimeScene.getObjects("YellowTang"), gdjs.GameCode.GDYellowTangObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRedSnapperObjects1ObjectsGDgdjs_9546GameCode_9546GDClownfishObjects1ObjectsGDgdjs_9546GameCode_9546GDParrotFishObjects1ObjectsGDgdjs_9546GameCode_9546GDYellowTangObjects1ObjectsGDgdjs_9546GameCode_9546GDLionfishObjects1ObjectsGDgdjs_9546GameCode_9546GDAnglerfishObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 200, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDAnglerfishObjects1 */
/* Reuse gdjs.GameCode.GDClownfishObjects1 */
/* Reuse gdjs.GameCode.GDLionfishObjects1 */
/* Reuse gdjs.GameCode.GDParrotFishObjects1 */
/* Reuse gdjs.GameCode.GDRedSnapperObjects1 */
/* Reuse gdjs.GameCode.GDSharkObjects1 */
/* Reuse gdjs.GameCode.GDYellowTangObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDRedSnapperObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDRedSnapperObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
for(var i = 0, len = gdjs.GameCode.GDClownfishObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDClownfishObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
for(var i = 0, len = gdjs.GameCode.GDParrotFishObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDParrotFishObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
for(var i = 0, len = gdjs.GameCode.GDYellowTangObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDYellowTangObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
for(var i = 0, len = gdjs.GameCode.GDLionfishObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDLionfishObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
for(var i = 0, len = gdjs.GameCode.GDAnglerfishObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnglerfishObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSharkObjects1Objects, 100, 16, null);
}
}
}

}


};gdjs.GameCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() > runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SumbitScoreButton"), gdjs.GameCode.GDSumbitScoreButtonObjects2);
{gdjs.evtTools.storage.writeNumberInJSONFile("Save", "Highscore", runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}
{for(var i = 0, len = gdjs.GameCode.GDSumbitScoreButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSumbitScoreButtonObjects2[i].Activate(true, null);
}
}
}

}


};gdjs.GameCode.asyncCallback21485108 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "8b2d8728-1a23-4509-b53e-4e77f8334f86", true);
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21485108, gdjs.GameCode.asyncCallback21485108);
gdjs.GameCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.leaderboards.saveConnectedPlayerScore(runtimeScene, "8b2d8728-1a23-4509-b53e-4e77f8334f86", runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()), (runtimeScene) => (gdjs.GameCode.asyncCallback21485108(runtimeScene, asyncObjectsList)), 21485108, asyncObjectsList);
}
}

}


};gdjs.GameCode.asyncCallback21486372 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "8b2d8728-1a23-4509-b53e-4e77f8334f86", true);
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21486372, gdjs.GameCode.asyncCallback21486372);
gdjs.GameCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.leaderboards.saveConnectedPlayerScore(runtimeScene, "8b2d8728-1a23-4509-b53e-4e77f8334f86", runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()), (runtimeScene) => (gdjs.GameCode.asyncCallback21486372(runtimeScene, asyncObjectsList)), 21486372, asyncObjectsList);
}
}

}


};gdjs.GameCode.asyncCallback21486132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);

{ //Subevents
gdjs.GameCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21486132, gdjs.GameCode.asyncCallback21486132);
gdjs.GameCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.playerAuthentication.openAuthenticationWindow(runtimeScene), (runtimeScene) => (gdjs.GameCode.asyncCallback21486132(runtimeScene, asyncObjectsList)), 21486132, asyncObjectsList);
}
}

}


};gdjs.GameCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.playerAuthentication.isAuthenticated();
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList28(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.playerAuthentication.isAuthenticated());
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback21487484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("SumbitScoreButton"), gdjs.GameCode.GDSumbitScoreButtonObjects3);

{for(var i = 0, len = gdjs.GameCode.GDSumbitScoreButtonObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSumbitScoreButtonObjects3[i].SetLabelText("SUBMIT SCORE", null);
}
}
gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.idToCallbackMap.set(21487484, gdjs.GameCode.asyncCallback21487484);
gdjs.GameCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
for (const obj of gdjs.GameCode.GDSumbitScoreButtonObjects2) asyncObjectsList.addObject("SumbitScoreButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback21487484(runtimeScene, asyncObjectsList)), 21487484, asyncObjectsList);
}
}

}


};gdjs.GameCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21481836);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Black"), gdjs.GameCode.GDBlackObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameOverScoreText"), gdjs.GameCode.GDGameOverScoreTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("HighscoreScoreText"), gdjs.GameCode.GDHighscoreScoreTextObjects2);
{for(var i = 0, len = gdjs.GameCode.GDBlackObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBlackObjects2[i].getBehavior("Opacity").setOpacity(100);
}
}
{for(var i = 0, len = gdjs.GameCode.GDGameOverScoreTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGameOverScoreTextObjects2[i].getBehavior("ScoreAnimation").SetValue(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDHighscoreScoreTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHighscoreScoreTextObjects2[i].getBehavior("Text").setText("Highscore: " + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}

{ //Subevents
gdjs.GameCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SumbitScoreButton"), gdjs.GameCode.GDSumbitScoreButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSumbitScoreButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSumbitScoreButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSumbitScoreButtonObjects2[k] = gdjs.GameCode.GDSumbitScoreButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSumbitScoreButtonObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList31(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.leaderboards.hasSavingErrored("8b2d8728-1a23-4509-b53e-4e77f8334f86");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21487220);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SumbitScoreButton"), gdjs.GameCode.GDSumbitScoreButtonObjects2);
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}
{for(var i = 0, len = gdjs.GameCode.GDSumbitScoreButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSumbitScoreButtonObjects2[i].SetLabelText("ERROR!", null);
}
}

{ //Subevents
gdjs.GameCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MenuButton"), gdjs.GameCode.GDMenuButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDMenuButtonObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDMenuButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDMenuButtonObjects1[k] = gdjs.GameCode.GDMenuButtonObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDMenuButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}
}

}


};gdjs.GameCode.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Game Over");
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SumbitScoreButton"), gdjs.GameCode.GDSumbitScoreButtonObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Game Over");
}
{for(var i = 0, len = gdjs.GameCode.GDSumbitScoreButtonObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSumbitScoreButtonObjects1[i].Activate(false, null);
}
}
{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}

{ //Subevents
gdjs.GameCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.GameCode.GDMoveJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMoveJoystickObjects1Objects, "Left", null);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDMoveJoystickObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMoveJoystickObjects1[i].TeleportAndPress(null);
}
}
}

}


{


gdjs.GameCode.eventsList11(runtimeScene);
}


{


gdjs.GameCode.eventsList15(runtimeScene);
}


{


gdjs.GameCode.eventsList17(runtimeScene);
}


{


gdjs.GameCode.eventsList26(runtimeScene);
}


{


gdjs.GameCode.eventsList34(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDSharkObjects1.length = 0;
gdjs.GameCode.GDSharkObjects2.length = 0;
gdjs.GameCode.GDSharkObjects3.length = 0;
gdjs.GameCode.GDSharkObjects4.length = 0;
gdjs.GameCode.GDSharkObjects5.length = 0;
gdjs.GameCode.GDCliff1Objects1.length = 0;
gdjs.GameCode.GDCliff1Objects2.length = 0;
gdjs.GameCode.GDCliff1Objects3.length = 0;
gdjs.GameCode.GDCliff1Objects4.length = 0;
gdjs.GameCode.GDCliff1Objects5.length = 0;
gdjs.GameCode.GDCliff3Objects1.length = 0;
gdjs.GameCode.GDCliff3Objects2.length = 0;
gdjs.GameCode.GDCliff3Objects3.length = 0;
gdjs.GameCode.GDCliff3Objects4.length = 0;
gdjs.GameCode.GDCliff3Objects5.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects1.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects2.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects3.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects4.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects5.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects1.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects2.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects3.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects4.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects5.length = 0;
gdjs.GameCode.GDMoveJoystickObjects1.length = 0;
gdjs.GameCode.GDMoveJoystickObjects2.length = 0;
gdjs.GameCode.GDMoveJoystickObjects3.length = 0;
gdjs.GameCode.GDMoveJoystickObjects4.length = 0;
gdjs.GameCode.GDMoveJoystickObjects5.length = 0;
gdjs.GameCode.GDFishSpawnerObjects1.length = 0;
gdjs.GameCode.GDFishSpawnerObjects2.length = 0;
gdjs.GameCode.GDFishSpawnerObjects3.length = 0;
gdjs.GameCode.GDFishSpawnerObjects4.length = 0;
gdjs.GameCode.GDFishSpawnerObjects5.length = 0;
gdjs.GameCode.GDRedSnapperObjects1.length = 0;
gdjs.GameCode.GDRedSnapperObjects2.length = 0;
gdjs.GameCode.GDRedSnapperObjects3.length = 0;
gdjs.GameCode.GDRedSnapperObjects4.length = 0;
gdjs.GameCode.GDRedSnapperObjects5.length = 0;
gdjs.GameCode.GDClownfishObjects1.length = 0;
gdjs.GameCode.GDClownfishObjects2.length = 0;
gdjs.GameCode.GDClownfishObjects3.length = 0;
gdjs.GameCode.GDClownfishObjects4.length = 0;
gdjs.GameCode.GDClownfishObjects5.length = 0;
gdjs.GameCode.GDParrotFishObjects1.length = 0;
gdjs.GameCode.GDParrotFishObjects2.length = 0;
gdjs.GameCode.GDParrotFishObjects3.length = 0;
gdjs.GameCode.GDParrotFishObjects4.length = 0;
gdjs.GameCode.GDParrotFishObjects5.length = 0;
gdjs.GameCode.GDYellowTangObjects1.length = 0;
gdjs.GameCode.GDYellowTangObjects2.length = 0;
gdjs.GameCode.GDYellowTangObjects3.length = 0;
gdjs.GameCode.GDYellowTangObjects4.length = 0;
gdjs.GameCode.GDYellowTangObjects5.length = 0;
gdjs.GameCode.GDHealthBarObjects1.length = 0;
gdjs.GameCode.GDHealthBarObjects2.length = 0;
gdjs.GameCode.GDHealthBarObjects3.length = 0;
gdjs.GameCode.GDHealthBarObjects4.length = 0;
gdjs.GameCode.GDHealthBarObjects5.length = 0;
gdjs.GameCode.GDScoreTextObjects1.length = 0;
gdjs.GameCode.GDScoreTextObjects2.length = 0;
gdjs.GameCode.GDScoreTextObjects3.length = 0;
gdjs.GameCode.GDScoreTextObjects4.length = 0;
gdjs.GameCode.GDScoreTextObjects5.length = 0;
gdjs.GameCode.GDAddScoreTextObjects1.length = 0;
gdjs.GameCode.GDAddScoreTextObjects2.length = 0;
gdjs.GameCode.GDAddScoreTextObjects3.length = 0;
gdjs.GameCode.GDAddScoreTextObjects4.length = 0;
gdjs.GameCode.GDAddScoreTextObjects5.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects1.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects2.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects3.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects4.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects5.length = 0;
gdjs.GameCode.GDStaminaBarObjects1.length = 0;
gdjs.GameCode.GDStaminaBarObjects2.length = 0;
gdjs.GameCode.GDStaminaBarObjects3.length = 0;
gdjs.GameCode.GDStaminaBarObjects4.length = 0;
gdjs.GameCode.GDStaminaBarObjects5.length = 0;
gdjs.GameCode.GDMultiplierTextObjects1.length = 0;
gdjs.GameCode.GDMultiplierTextObjects2.length = 0;
gdjs.GameCode.GDMultiplierTextObjects3.length = 0;
gdjs.GameCode.GDMultiplierTextObjects4.length = 0;
gdjs.GameCode.GDMultiplierTextObjects5.length = 0;
gdjs.GameCode.GDLionfishObjects1.length = 0;
gdjs.GameCode.GDLionfishObjects2.length = 0;
gdjs.GameCode.GDLionfishObjects3.length = 0;
gdjs.GameCode.GDLionfishObjects4.length = 0;
gdjs.GameCode.GDLionfishObjects5.length = 0;
gdjs.GameCode.GDAnglerfishObjects1.length = 0;
gdjs.GameCode.GDAnglerfishObjects2.length = 0;
gdjs.GameCode.GDAnglerfishObjects3.length = 0;
gdjs.GameCode.GDAnglerfishObjects4.length = 0;
gdjs.GameCode.GDAnglerfishObjects5.length = 0;
gdjs.GameCode.GDBlackObjects1.length = 0;
gdjs.GameCode.GDBlackObjects2.length = 0;
gdjs.GameCode.GDBlackObjects3.length = 0;
gdjs.GameCode.GDBlackObjects4.length = 0;
gdjs.GameCode.GDBlackObjects5.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects1.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects2.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects3.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects4.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects5.length = 0;
gdjs.GameCode.GDMenuButtonObjects1.length = 0;
gdjs.GameCode.GDMenuButtonObjects2.length = 0;
gdjs.GameCode.GDMenuButtonObjects3.length = 0;
gdjs.GameCode.GDMenuButtonObjects4.length = 0;
gdjs.GameCode.GDMenuButtonObjects5.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects1.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects2.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects3.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects4.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects5.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects1.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects2.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects3.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects4.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects5.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects1.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects2.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects3.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects4.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects5.length = 0;
gdjs.GameCode.GDObstacleObjects1.length = 0;
gdjs.GameCode.GDObstacleObjects2.length = 0;
gdjs.GameCode.GDObstacleObjects3.length = 0;
gdjs.GameCode.GDObstacleObjects4.length = 0;
gdjs.GameCode.GDObstacleObjects5.length = 0;
gdjs.GameCode.GDMineObjects1.length = 0;
gdjs.GameCode.GDMineObjects2.length = 0;
gdjs.GameCode.GDMineObjects3.length = 0;
gdjs.GameCode.GDMineObjects4.length = 0;
gdjs.GameCode.GDMineObjects5.length = 0;
gdjs.GameCode.GDRedExplosionObjects1.length = 0;
gdjs.GameCode.GDRedExplosionObjects2.length = 0;
gdjs.GameCode.GDRedExplosionObjects3.length = 0;
gdjs.GameCode.GDRedExplosionObjects4.length = 0;
gdjs.GameCode.GDRedExplosionObjects5.length = 0;
gdjs.GameCode.GDGrassObjects1.length = 0;
gdjs.GameCode.GDGrassObjects2.length = 0;
gdjs.GameCode.GDGrassObjects3.length = 0;
gdjs.GameCode.GDGrassObjects4.length = 0;
gdjs.GameCode.GDGrassObjects5.length = 0;
gdjs.GameCode.GDGrass2Objects1.length = 0;
gdjs.GameCode.GDGrass2Objects2.length = 0;
gdjs.GameCode.GDGrass2Objects3.length = 0;
gdjs.GameCode.GDGrass2Objects4.length = 0;
gdjs.GameCode.GDGrass2Objects5.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects1.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects2.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects3.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects4.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects5.length = 0;
gdjs.GameCode.GDTopBoundaryObjects1.length = 0;
gdjs.GameCode.GDTopBoundaryObjects2.length = 0;
gdjs.GameCode.GDTopBoundaryObjects3.length = 0;
gdjs.GameCode.GDTopBoundaryObjects4.length = 0;
gdjs.GameCode.GDTopBoundaryObjects5.length = 0;
gdjs.GameCode.GDRightBoundaryObjects1.length = 0;
gdjs.GameCode.GDRightBoundaryObjects2.length = 0;
gdjs.GameCode.GDRightBoundaryObjects3.length = 0;
gdjs.GameCode.GDRightBoundaryObjects4.length = 0;
gdjs.GameCode.GDRightBoundaryObjects5.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects1.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects2.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects3.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects4.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects5.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects1.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects2.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects3.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects4.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects5.length = 0;

gdjs.GameCode.eventsList35(runtimeScene);
gdjs.GameCode.GDSharkObjects1.length = 0;
gdjs.GameCode.GDSharkObjects2.length = 0;
gdjs.GameCode.GDSharkObjects3.length = 0;
gdjs.GameCode.GDSharkObjects4.length = 0;
gdjs.GameCode.GDSharkObjects5.length = 0;
gdjs.GameCode.GDCliff1Objects1.length = 0;
gdjs.GameCode.GDCliff1Objects2.length = 0;
gdjs.GameCode.GDCliff1Objects3.length = 0;
gdjs.GameCode.GDCliff1Objects4.length = 0;
gdjs.GameCode.GDCliff1Objects5.length = 0;
gdjs.GameCode.GDCliff3Objects1.length = 0;
gdjs.GameCode.GDCliff3Objects2.length = 0;
gdjs.GameCode.GDCliff3Objects3.length = 0;
gdjs.GameCode.GDCliff3Objects4.length = 0;
gdjs.GameCode.GDCliff3Objects5.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects1.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects2.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects3.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects4.length = 0;
gdjs.GameCode.GDBloodParticleEmitterObjects5.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects1.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects2.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects3.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects4.length = 0;
gdjs.GameCode.GDSeaAndSkyObjects5.length = 0;
gdjs.GameCode.GDMoveJoystickObjects1.length = 0;
gdjs.GameCode.GDMoveJoystickObjects2.length = 0;
gdjs.GameCode.GDMoveJoystickObjects3.length = 0;
gdjs.GameCode.GDMoveJoystickObjects4.length = 0;
gdjs.GameCode.GDMoveJoystickObjects5.length = 0;
gdjs.GameCode.GDFishSpawnerObjects1.length = 0;
gdjs.GameCode.GDFishSpawnerObjects2.length = 0;
gdjs.GameCode.GDFishSpawnerObjects3.length = 0;
gdjs.GameCode.GDFishSpawnerObjects4.length = 0;
gdjs.GameCode.GDFishSpawnerObjects5.length = 0;
gdjs.GameCode.GDRedSnapperObjects1.length = 0;
gdjs.GameCode.GDRedSnapperObjects2.length = 0;
gdjs.GameCode.GDRedSnapperObjects3.length = 0;
gdjs.GameCode.GDRedSnapperObjects4.length = 0;
gdjs.GameCode.GDRedSnapperObjects5.length = 0;
gdjs.GameCode.GDClownfishObjects1.length = 0;
gdjs.GameCode.GDClownfishObjects2.length = 0;
gdjs.GameCode.GDClownfishObjects3.length = 0;
gdjs.GameCode.GDClownfishObjects4.length = 0;
gdjs.GameCode.GDClownfishObjects5.length = 0;
gdjs.GameCode.GDParrotFishObjects1.length = 0;
gdjs.GameCode.GDParrotFishObjects2.length = 0;
gdjs.GameCode.GDParrotFishObjects3.length = 0;
gdjs.GameCode.GDParrotFishObjects4.length = 0;
gdjs.GameCode.GDParrotFishObjects5.length = 0;
gdjs.GameCode.GDYellowTangObjects1.length = 0;
gdjs.GameCode.GDYellowTangObjects2.length = 0;
gdjs.GameCode.GDYellowTangObjects3.length = 0;
gdjs.GameCode.GDYellowTangObjects4.length = 0;
gdjs.GameCode.GDYellowTangObjects5.length = 0;
gdjs.GameCode.GDHealthBarObjects1.length = 0;
gdjs.GameCode.GDHealthBarObjects2.length = 0;
gdjs.GameCode.GDHealthBarObjects3.length = 0;
gdjs.GameCode.GDHealthBarObjects4.length = 0;
gdjs.GameCode.GDHealthBarObjects5.length = 0;
gdjs.GameCode.GDScoreTextObjects1.length = 0;
gdjs.GameCode.GDScoreTextObjects2.length = 0;
gdjs.GameCode.GDScoreTextObjects3.length = 0;
gdjs.GameCode.GDScoreTextObjects4.length = 0;
gdjs.GameCode.GDScoreTextObjects5.length = 0;
gdjs.GameCode.GDAddScoreTextObjects1.length = 0;
gdjs.GameCode.GDAddScoreTextObjects2.length = 0;
gdjs.GameCode.GDAddScoreTextObjects3.length = 0;
gdjs.GameCode.GDAddScoreTextObjects4.length = 0;
gdjs.GameCode.GDAddScoreTextObjects5.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects1.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects2.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects3.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects4.length = 0;
gdjs.GameCode.GDFastSwimButtonObjects5.length = 0;
gdjs.GameCode.GDStaminaBarObjects1.length = 0;
gdjs.GameCode.GDStaminaBarObjects2.length = 0;
gdjs.GameCode.GDStaminaBarObjects3.length = 0;
gdjs.GameCode.GDStaminaBarObjects4.length = 0;
gdjs.GameCode.GDStaminaBarObjects5.length = 0;
gdjs.GameCode.GDMultiplierTextObjects1.length = 0;
gdjs.GameCode.GDMultiplierTextObjects2.length = 0;
gdjs.GameCode.GDMultiplierTextObjects3.length = 0;
gdjs.GameCode.GDMultiplierTextObjects4.length = 0;
gdjs.GameCode.GDMultiplierTextObjects5.length = 0;
gdjs.GameCode.GDLionfishObjects1.length = 0;
gdjs.GameCode.GDLionfishObjects2.length = 0;
gdjs.GameCode.GDLionfishObjects3.length = 0;
gdjs.GameCode.GDLionfishObjects4.length = 0;
gdjs.GameCode.GDLionfishObjects5.length = 0;
gdjs.GameCode.GDAnglerfishObjects1.length = 0;
gdjs.GameCode.GDAnglerfishObjects2.length = 0;
gdjs.GameCode.GDAnglerfishObjects3.length = 0;
gdjs.GameCode.GDAnglerfishObjects4.length = 0;
gdjs.GameCode.GDAnglerfishObjects5.length = 0;
gdjs.GameCode.GDBlackObjects1.length = 0;
gdjs.GameCode.GDBlackObjects2.length = 0;
gdjs.GameCode.GDBlackObjects3.length = 0;
gdjs.GameCode.GDBlackObjects4.length = 0;
gdjs.GameCode.GDBlackObjects5.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects1.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects2.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects3.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects4.length = 0;
gdjs.GameCode.GDGameOverScoreTextObjects5.length = 0;
gdjs.GameCode.GDMenuButtonObjects1.length = 0;
gdjs.GameCode.GDMenuButtonObjects2.length = 0;
gdjs.GameCode.GDMenuButtonObjects3.length = 0;
gdjs.GameCode.GDMenuButtonObjects4.length = 0;
gdjs.GameCode.GDMenuButtonObjects5.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects1.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects2.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects3.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects4.length = 0;
gdjs.GameCode.GDSumbitScoreButtonObjects5.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects1.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects2.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects3.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects4.length = 0;
gdjs.GameCode.GDHighscoreScoreTextObjects5.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects1.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects2.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects3.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects4.length = 0;
gdjs.GameCode.GDSharkSpawnPointObjects5.length = 0;
gdjs.GameCode.GDObstacleObjects1.length = 0;
gdjs.GameCode.GDObstacleObjects2.length = 0;
gdjs.GameCode.GDObstacleObjects3.length = 0;
gdjs.GameCode.GDObstacleObjects4.length = 0;
gdjs.GameCode.GDObstacleObjects5.length = 0;
gdjs.GameCode.GDMineObjects1.length = 0;
gdjs.GameCode.GDMineObjects2.length = 0;
gdjs.GameCode.GDMineObjects3.length = 0;
gdjs.GameCode.GDMineObjects4.length = 0;
gdjs.GameCode.GDMineObjects5.length = 0;
gdjs.GameCode.GDRedExplosionObjects1.length = 0;
gdjs.GameCode.GDRedExplosionObjects2.length = 0;
gdjs.GameCode.GDRedExplosionObjects3.length = 0;
gdjs.GameCode.GDRedExplosionObjects4.length = 0;
gdjs.GameCode.GDRedExplosionObjects5.length = 0;
gdjs.GameCode.GDGrassObjects1.length = 0;
gdjs.GameCode.GDGrassObjects2.length = 0;
gdjs.GameCode.GDGrassObjects3.length = 0;
gdjs.GameCode.GDGrassObjects4.length = 0;
gdjs.GameCode.GDGrassObjects5.length = 0;
gdjs.GameCode.GDGrass2Objects1.length = 0;
gdjs.GameCode.GDGrass2Objects2.length = 0;
gdjs.GameCode.GDGrass2Objects3.length = 0;
gdjs.GameCode.GDGrass2Objects4.length = 0;
gdjs.GameCode.GDGrass2Objects5.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects1.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects2.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects3.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects4.length = 0;
gdjs.GameCode.GDLeftBoundaryObjects5.length = 0;
gdjs.GameCode.GDTopBoundaryObjects1.length = 0;
gdjs.GameCode.GDTopBoundaryObjects2.length = 0;
gdjs.GameCode.GDTopBoundaryObjects3.length = 0;
gdjs.GameCode.GDTopBoundaryObjects4.length = 0;
gdjs.GameCode.GDTopBoundaryObjects5.length = 0;
gdjs.GameCode.GDRightBoundaryObjects1.length = 0;
gdjs.GameCode.GDRightBoundaryObjects2.length = 0;
gdjs.GameCode.GDRightBoundaryObjects3.length = 0;
gdjs.GameCode.GDRightBoundaryObjects4.length = 0;
gdjs.GameCode.GDRightBoundaryObjects5.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects1.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects2.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects3.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects4.length = 0;
gdjs.GameCode.GDBottomBoundaryObjects5.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects1.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects2.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects3.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects4.length = 0;
gdjs.GameCode.GDBubblesParticleEmitterObjects5.length = 0;


return;

}

gdjs['GameCode'] = gdjs.GameCode;
